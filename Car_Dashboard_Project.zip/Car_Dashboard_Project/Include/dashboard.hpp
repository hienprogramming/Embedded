#ifndef DASHBOARD_HPP
#define DASHBOARD_HPP

#include "vehicle_data.hpp"
#include <windows.h>

class Dashboard {
public:
    Dashboard();
    void init();
    void update(const VehicleData& data);
    bool shouldExit();
    void handleInput();
    void clearScreen();
private:
    bool exitFlag;
};

#endif