#ifndef VEHICLE_DATA_HPP
#define VEHICLE_DATA_HPP

#include <string>

struct VehicleData {
    double speed;
    int rpm;
    double fuel;
    double temperature;
};

class VehicleDataManager {
public:
    VehicleDataManager();
    void loadFromCSV(const std::string& filename);
    void updateData();
    VehicleData getCurrentData();
private:
    VehicleData currentData;
};

#endif