#include "dashboard.hpp"
#include "vehicle_data.hpp"
#include <windows.h>

int main() {
    VehicleDataManager dataManager;
    Dashboard dashboard;
    
    dashboard.init();
    dataManager.loadFromCSV("database.csv");
    
    while (!dashboard.shouldExit()) {
        dataManager.updateData();
        VehicleData currentData = dataManager.getCurrentData();
        dashboard.update(currentData);
        dashboard.handleInput();
        Sleep(100); // Sleep for 100ms
    }
    
    return 0;
}