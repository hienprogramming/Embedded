#include "vehicle_data.hpp"
#include <fstream>
#include <random>

VehicleDataManager::VehicleDataManager() {
    currentData = {0, 0, 0, 0};
}

void VehicleDataManager::loadFromCSV(const std::string& filename) {
    // Simulate loading initial data
    currentData.speed = 60.0;
    currentData.rpm = 2000;
    currentData.fuel = 45.0;
    currentData.temperature = 90.0;
}

void VehicleDataManager::updateData() {
    // Simulate data changes
    static std::random_device rd;
    static std::mt19937 gen(rd());
    static std::uniform_real_distribution<> dis(-1.0, 1.0);

    currentData.speed += dis(gen);
    currentData.rpm += static_cast<int>(dis(gen) * 10);
    currentData.fuel -= 0.01;
    currentData.temperature += dis(gen) * 0.1;
}

VehicleData VehicleDataManager::getCurrentData() {
    return currentData;
}