#include "dashboard.hpp"
#include <iostream>
#include <conio.h>

Dashboard::Dashboard() : exitFlag(false) {}

void Dashboard::init() {
    clearScreen();
}

void Dashboard::clearScreen() {
    system("cls");
}

void Dashboard::update(const VehicleData& data) {
    clearScreen();
    std::cout << "===== Car Dashboard =====" << std::endl;
    std::cout << "Speed: " << data.speed << " km/h" << std::endl;
    std::cout << "RPM: " << data.rpm << std::endl;
    std::cout << "Fuel: " << data.fuel << " L" << std::endl;
    std::cout << "Temperature: " << data.temperature << " C" << std::endl;
    std::cout << "\nPress 'q' to exit" << std::endl;
}

bool Dashboard::shouldExit() {
    return exitFlag;
}

void Dashboard::handleInput() {
    if (_kbhit()) {
        char ch = _getch();
        if (ch == 'q' || ch == 'Q') {
            exitFlag = true;
        }
    }
}